package com.exception;

public class NoSquareException extends Exception {

	public NoSquareException() {
		super();
		// TODO Auto-generated constructor stub
	
	}

	public NoSquareException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
